public class BLL {

    public static void validaCripto(Cripto umpalavra) {
        Erro.setErro(false);

        if (umpalavra.getPalavra().equals("")) {
            Erro.setErro("O campo PALAVRA é de preenchimento obrigatório...");
            return;
        }

        if (umpalavra.getChave().equals("")) {
            Erro.setErro("O campo CHAVE é de preenchimento obrigatório...");
            return;
        }
    }

    public static void validaDescripto(Cripto umpalavra, boolean criptografado, String chaveDigitada) {
        Erro.setErro(false);

        if (!criptografado) {
            Erro.setErro("É necessário criptografar antes de descriptografar.");
            return;
        }

        if (umpalavra.getPalavra().equals("")) {
            Erro.setErro("O campo PALAVRA é de preenchimento obrigatório...");
            return;
        }

        if (chaveDigitada.equals("")) {
            Erro.setErro("O campo CHAVE é de preenchimento obrigatório...");
            return;
        }

        if (!chaveDigitada.equals(umpalavra.getChave())) {
            Erro.setErro("Chave inválida! Por favor, insira a chave correta.");
            return;
        }
    }
}
