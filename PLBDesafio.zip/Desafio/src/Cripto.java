public class Cripto {
    private String palavra;
    private String chave;
    private String textoCriptografado;
    private boolean criptografado = false;

    public void setPalavra(String _palavra) { palavra = _palavra; }
    public void setChave(String _chave) { chave = _chave; }
    public String getPalavra() { return palavra; }
    public String getChave() { return chave; }
    public String getTextoCriptografado() { return textoCriptografado; }
    public boolean isCriptografado() { return criptografado; }
    public void setCriptografado(boolean c) { criptografado = c; }


public String calcCripto() {
    StringBuilder resultado = new StringBuilder(); 
    int a = palavra.length();
    int r = chave.length();
    for (int i = 0; i < palavra.length(); i++) {
        char letraPalavra = palavra.charAt(i);
        char letraChave   = chave.charAt(i % chave.length());

        int xor = letraPalavra ^ letraChave;
        int somaIndice = xor + i;
        int termoPG = (int)(a * Math.pow(r, i)); 
        int cifrado = somaIndice * termoPG;

        resultado.append(cifrado).append(i < palavra.length() - 1 ? " " : "");
    }
    textoCriptografado = resultado.toString();
    criptografado = true;
    return textoCriptografado;
}
public String calcDescripto(String textoCriptografado) {
    String[] partes = textoCriptografado.split(" ");
    StringBuilder resultado = new StringBuilder();

    int a = partes.length;      
    int r = chave.length();

    for (int i = 0; i < partes.length; i++) {
        int cifra = Integer.parseInt(partes[i]);
        int termoPG = (int)(a * Math.pow(r, i));
        int valorOriginal= cifra / termoPG;
        int xor = valorOriginal - i;

        char letraChave = chave.charAt(i % chave.length());
        int original = xor ^ letraChave;
        resultado.append((char) original);
    }

    return resultado.toString();
}
}
